	(function($) {
		"use strict";
	
	$(document).ready(function(){
		
	$('#parallax-1').parallax("50%", 0.1);
	$('#parallax-2').parallax("50%", 0.1);
	$('#parallax-3').parallax("50%", 0.4);
	$('#parallax-4').parallax("50%", 0.3);

})

	
	

	
	})(jQuery);