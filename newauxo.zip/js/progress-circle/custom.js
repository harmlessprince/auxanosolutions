	(function($) {
		"use strict";
	
	

	$(function () {
	$('.percent').percentageLoader({
		valElement: 'p',
		strokeWidth:5,
		bgColor: 'rgba(255, 255, 255, 0.1)',
		ringColor: '#ecae3d',
		textColor: '#fff',
		fontSize: '24px',
		fontWeight: 'normal'
	});

	});


	$(function () {
	$('.percent-2').percentageLoader({
		valElement: 'p',
		strokeWidth:5,
		bgColor: 'rgba(255, 255, 255, 0.1)',
		ringColor: '#ecae3d',
		textColor: '#fff',
		fontSize: '24px',
		fontWeight: 'normal'
	});

	});







	

	
	})(jQuery);